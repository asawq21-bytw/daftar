<?php
$id_telegram = "7142327444";
$id_botTele  = "6666547725:AAFmiw6GK8K-P7gc1rqhWpEvMP4aXL_dFic";
?>